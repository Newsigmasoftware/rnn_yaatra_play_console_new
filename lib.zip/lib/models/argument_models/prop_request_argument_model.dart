class PropRequestArgumentModel {
  final bool? isRegisterNewMemeber;

  PropRequestArgumentModel({
    this.isRegisterNewMemeber = false,
  });

  // Factory constructor to create an instance from a JSON map
  factory PropRequestArgumentModel.fromJson(Map<String, dynamic> json) {
    return PropRequestArgumentModel(
      isRegisterNewMemeber: json['isRegisterNewMemeber'] as bool? ?? false,
    );
  }

  // Method to convert an instance into a JSON map
  Map<String, dynamic> toJson() {
    return {
      'isRegisterNewMemeber': isRegisterNewMemeber,
    };
  }

  // Handy copyWith method for state management/navigation
  PropRequestArgumentModel copyWith({
    bool? isRegisterNewMemeber,
  }) {
    return PropRequestArgumentModel(
      isRegisterNewMemeber: isRegisterNewMemeber ?? this.isRegisterNewMemeber,
    );
  }
}