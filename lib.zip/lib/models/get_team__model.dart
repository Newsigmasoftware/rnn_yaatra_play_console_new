class GetTeamModel {
  bool? success;
  List<Data>? data;
  int? count;

  GetTeamModel({this.success, this.data, this.count});

  GetTeamModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(new Data.fromJson(v));
      });
    }
    count = json['count'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['count'] = this.count;
    return data;
  }
}

class Data {
  int? id;
  String? userId;
  String? userName;
  String? sponsorId;
  String? sponsorName;
  String? topupAmount;
  String? photo;
  String? mobile;
  String? email;
  String? status;
  String? activationDate;
  String? regDate;
  String? totalActiveDirect;
  String? totalDeactiveDirect;
  String? totalActiveTeam;
  String? totalDeactiveTeam;
  String? active;
  String? deactive;
  String? direction;
  String? level;
  String? placementUserId;

  Data(
      {this.id,
        this.userId,
        this.userName,
        this.sponsorId,
        this.sponsorName,
        this.direction,
        this.topupAmount,
        this.photo,
        this.mobile,
        this.email,
        this.status,
        this.activationDate,
        this.regDate,
        this.totalActiveDirect,
        this.totalDeactiveDirect,
        this.totalActiveTeam,
        this.totalDeactiveTeam,
        this.active,
        this.deactive,
        this.level,
        this.placementUserId});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['Id'];
    userId = json['UserId'];
    userName = json['UserName'];
    sponsorId = json['SponsorId'];
    sponsorName = json['SponsorName'];
    direction = json['Direction'];
    topupAmount = json['TopupAmount'];
    photo = json['Photo'];
    mobile = json['Mobile'];
    email = json['Email'];
    status = json['Status'];
    activationDate = json['ActivationDate'];
    regDate = json['RegDate'];
    totalActiveDirect = json['TotalActiveDirect'];
    totalDeactiveDirect = json['TotalDeactiveDirect'];
    totalActiveTeam = json['TotalActiveTeam'];
    totalDeactiveTeam = json['TotalDeactiveTeam'];
    active = json['active'];
    deactive = json['deactive'];
    direction = json['direction'];
    level = json['level'];
    placementUserId = json['PlacementUserId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Id'] = this.id;
    data['UserId'] = this.userId;
    data['UserName'] = this.userName;
    data['SponsorId'] = this.sponsorId;
    data['SponsorName'] = this.sponsorName;
    data['Direction'] = this.direction;
    data['TopupAmount'] = this.topupAmount;
    data['Photo'] = this.photo;
    data['Mobile'] = this.mobile;
    data['Email'] = this.email;
    data['Status'] = this.status;
    data['ActivationDate'] = this.activationDate;
    data['RegDate'] = this.regDate;
    data['TotalActiveDirect'] = this.totalActiveDirect;
    data['TotalDeactiveDirect'] = this.totalDeactiveDirect;
    data['TotalActiveTeam'] = this.totalActiveTeam;
    data['TotalDeactiveTeam'] = this.totalDeactiveTeam;
    data['active'] = this.active;
    data['deactive'] = this.deactive;
    data['direction'] = this.direction;
    data['level'] = this.level;
    data['PlacementUserId'] = this.placementUserId;
    return data;
  }
}
