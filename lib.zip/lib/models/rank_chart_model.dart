class RankChartModel {
  bool? success;
  List<Data>? data;
  int? count;

  RankChartModel({this.success, this.data, this.count});

  RankChartModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(new Data.fromJson(v));
      });
    }
    count = json['count'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['count'] = this.count;
    return data;
  }
}

class Data {
  String? rankName;
  String? targetTeam;
  String? leftTeam;
  String? rightTeam;
  String? salaryAmount;
  String? entryDate;
  String? status;
  String? statusMobile;

  Data(
      {this.rankName,
        this.targetTeam,
        this.leftTeam,
        this.rightTeam,
        this.salaryAmount,
        this.entryDate,
        this.status,
        this.statusMobile});

  Data.fromJson(Map<String, dynamic> json) {
    rankName = json['RankName'];
    targetTeam = json['TargetTeam'];
    leftTeam = json['LeftTeam'];
    rightTeam = json['RightTeam'];
    salaryAmount = json['SalaryAmount'];
    entryDate = json['EntryDate'];
    status = json['Status'];
    statusMobile = json['StatusMobile'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['RankName'] = this.rankName;
    data['TargetTeam'] = this.targetTeam;
    data['LeftTeam'] = this.leftTeam;
    data['RightTeam'] = this.rightTeam;
    data['SalaryAmount'] = this.salaryAmount;
    data['EntryDate'] = this.entryDate;
    data['Status'] = this.status;
    data['StatusMobile'] = this.statusMobile;
    return data;
  }
}
