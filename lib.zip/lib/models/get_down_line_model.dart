class GetDownLineModel {
  bool? success;
  List<DownLineData>? data;
  int? count;

  GetDownLineModel({this.success, this.data, this.count});

  GetDownLineModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <DownLineData>[];
      json['data'].forEach((v) {
        data!.add(new DownLineData.fromJson(v));
      });
    }
    count = json['count'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['count'] = this.count;
    return data;
  }
}

class DownLineData {
  int? id;
  String? userId;
  String? userName;
  String? sponsorId;
  String? sponsorName;
  String? direction;
  String? parentUserId;
  String? parentName;
  String? topupAmount;
  String? email;
  String? mobile;
  String? photo;
  String? activationDate;
  String? regDate;
  String? totalActiveDirect;
  String? totalActiveTeam;
  String? totalDeactiveDirect;
  String? totalDeactiveTeam;
  String? status;

  DownLineData(
      {this.id,
      this.userId,
      this.userName,
      this.sponsorId,
      this.sponsorName,
      this.direction,
      this.parentUserId,
      this.parentName,
      this.topupAmount,
      this.email,
      this.mobile,
      this.photo,
      this.activationDate,
      this.regDate,
      this.totalActiveDirect,
      this.totalActiveTeam,
      this.totalDeactiveDirect,
      this.totalDeactiveTeam,
      this.status});

  DownLineData.fromJson(Map<String, dynamic> json) {
    id = json['Id'];
    userId = json['UserId'];
    userName = json['UserName'];
    sponsorId = json['SponsorId'];
    sponsorName = json['SponsorName'];
    direction = json['Direction'];
    parentUserId = json['ParentUserId'];
    parentName = json['ParentName'];
    topupAmount = json['TopupAmount'];
    email = json['Email'];
    mobile = json['Mobile'];
    photo = json['Photo'];
    activationDate = json['ActivationDate'];
    regDate = json['RegDate'];
    totalActiveDirect = json['TotalActiveDirect'];
    totalActiveTeam = json['TotalActiveTeam'];
    totalDeactiveDirect = json['TotalDeactiveDirect'];
    totalDeactiveTeam = json['TotalDeactiveTeam'];
    status = json['Status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Id'] = this.id;
    data['UserId'] = this.userId;
    data['UserName'] = this.userName;
    data['SponsorId'] = this.sponsorId;
    data['SponsorName'] = this.sponsorName;
    data['Direction'] = this.direction;
    data['ParentUserId'] = this.parentUserId;
    data['ParentName'] = this.parentName;
    data['TopupAmount'] = this.topupAmount;
    data['Email'] = this.email;
    data['Mobile'] = this.mobile;
    data['Photo'] = this.photo;
    data['ActivationDate'] = this.activationDate;
    data['RegDate'] = this.regDate;
    data['TotalActiveDirect'] = this.totalActiveDirect;
    data['TotalActiveTeam'] = this.totalActiveTeam;
    data['TotalDeactiveDirect'] = this.totalDeactiveDirect;
    data['TotalDeactiveTeam'] = this.totalDeactiveTeam;
    data['Status'] = this.status;
    return data;
  }
}
