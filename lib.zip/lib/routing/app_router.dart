// ignore_for_file: non_constant_identifier_names
  
import 'package:rnn_yaatra/helpers/navigation_helper.dart';
import 'package:rnn_yaatra/main.dart';
import 'package:rnn_yaatra/views/pages/account/edit_profile.dart';
import 'package:rnn_yaatra/views/pages/account/kyc_verification.dart';
import 'package:rnn_yaatra/views/pages/auth/login.dart'; 
import 'package:rnn_yaatra/views/pages/fund_management/deposit_request.dart';
import 'package:rnn_yaatra/views/pages/fund_management/fund_menu.dart';
import 'package:rnn_yaatra/views/pages/fund_management/fund_request_report.dart';
import 'package:rnn_yaatra/views/pages/home/dashboard.dart';
import 'package:rnn_yaatra/views/pages/home/home.dart';
import 'package:rnn_yaatra/views/pages/incomes/aip_income.dart';
import 'package:rnn_yaatra/views/pages/incomes/income_menus.dart';
import 'package:rnn_yaatra/views/pages/incomes/lip_income.dart';
import 'package:rnn_yaatra/views/pages/incomes/reward_pool_income.dart';
import 'package:rnn_yaatra/views/pages/ledger/income_ledger.dart';
import 'package:rnn_yaatra/views/pages/our_services/our_services_menu.dart';
import 'package:rnn_yaatra/views/pages/our_services/puchase_plan.dart';
import 'package:rnn_yaatra/views/pages/our_services/purchase_report.dart';
import 'package:rnn_yaatra/views/pages/password_management/change_login_password.dart';
import 'package:rnn_yaatra/views/pages/password_management/change_transaction_password.dart';
import 'package:rnn_yaatra/views/pages/password_management/password_menu.dart';
import 'package:rnn_yaatra/views/pages/rank/rank_chart.dart';
import 'package:rnn_yaatra/views/pages/team/direct_team.dart';
import 'package:rnn_yaatra/views/pages/team/downline_team.dart';
import 'package:rnn_yaatra/views/pages/team/team_menu.dart'; 
import 'package:rnn_yaatra/views/pages/welcome/splash_screen.dart'; 
import 'package:go_router/go_router.dart';
import 'package:rnn_yaatra/views/pages/withdrawal_management/withdrawal_report.dart';
// import 'package:rnn_yaatra/views/pages/withdrawal_manag

import 'package:rnn_yaatra/views/pages/reported_me/dart/raise_ticket_detail_screen.dart';
import 'package:rnn_yaatra/views/pages/reported_me/dart/raise_ticket_screen.dart';
import 'package:rnn_yaatra/views/pages/reported_me/dart/report_screen.dart';
// import '../views/pages/withdrawal_management/withdrawal_report.dart'
// ;ement/withdrawal_report.dart';

class AppRouter {

  static GoRouter router = GoRouter(
    navigatorKey: navigatorKey,
    initialLocation: '/',
    routes: [
      GoRoute(
        path: '/',
        builder: (context, state) => RootRun(),
      ),
      GoRoute(
        path: AppRouteString.SPLASH_SCREEN,
        builder: (context, state) => SplashScreen(),
      ),
      GoRoute(
        path: AppRouteString.Login,
        builder: (context, state) => Login(),
      ),
       
      GoRoute(
        path: AppRouteString.Home,
        builder: (context, state) => Home(),
      ),
      GoRoute(
        path: AppRouteString.Dashboard,
        builder: (context, state) => Dashboard(),
      ),
      GoRoute(
        path: AppRouteString.IncomeMenus,
        builder: (context, state) => IncomeMenus(),
      ),
      GoRoute(
        path: AppRouteString.AipIncome,
        builder: (context, state) => AipIncome(),
      ),
      GoRoute(
        path: AppRouteString.LipIncome,
        builder: (context, state) => LipIncome(),
      ),
      GoRoute(
        path: AppRouteString.RewardPoolIncome,
        builder: (context, state) => RewardPoolIncome(),
      ),
      GoRoute(
        path: AppRouteString.RankChart,
        builder: (context, state) => RankChart(),
      ),
      GoRoute(
        path: AppRouteString.KycVerification,
        builder: (context, state) => KycVerification(),
      ),
      GoRoute(
        path: AppRouteString.OurServicesMenu,
        builder: (context, state) => OurServicesMenu(),
      ),
      GoRoute(
        path: AppRouteString.PuchasePlan,
        builder: (context, state) => PuchasePlan(),
      ),
      GoRoute(
        path: AppRouteString.PurchaseReport,
        builder: (context, state) => PurchaseReport(),
      ),
      GoRoute(
        path: AppRouteString.TeamMenu,
        builder: (context, state) => TeamMenu(),
      ),
      GoRoute(
        path: AppRouteString.DirectTeam,
        builder: (context, state) => DirectTeam(),
      ),
      GoRoute(
        path: AppRouteString.DownlineTeam,
        builder: (context, state) => DownlineTeam(),
      ),
      GoRoute(
        path: AppRouteString.IncomeLedger,
        builder: (context, state) => IncomeLedger(),
      ),
      GoRoute(
        path: AppRouteString.FundMenu,
        builder: (context, state) => FundMenu(),
      ),
      GoRoute(
        path: AppRouteString.ReportedMe,
        builder: (context, state) => ReportScreen(),
      ),
      GoRoute(
        path: AppRouteString.DepositRequest,
        builder: (context, state) => DepositRequest(),
      ),
      GoRoute(
        path: AppRouteString.FundRequestReport,
        builder: (context, state) => FundRequestReport(),
      ),
      GoRoute(
        path: AppRouteString.WithdrawalReport,
        builder: (context, state) => WithdrawalReport(),
      ),
      GoRoute(
        path: AppRouteString.PasswordMenu,
        builder: (context, state) => PasswordMenu(),
      ),
      GoRoute(
        path: AppRouteString.ChangeLoginPassword,
        builder: (context, state) => ChangeLoginPassword(),
      ),
      GoRoute(
        path: AppRouteString.ChangeTransactionPassword,
        builder: (context, state) => ChangeTransactionPassword(),
      ),
      GoRoute(
        path: AppRouteString.EditProfile,
        builder: (context, state) => EditProfile(),
      ),
      GoRoute(
        path: AppRouteString.RaiseTicketScreen,
        builder: (context, state) => const RaiseTicketScreen(),
      ),
      GoRoute(
        path: AppRouteString.RaiseTicketDetailScreen,
        builder: (context, state) => const RaiseTicketDetailScreen(),
      ),

    ],
  );

}


class AppRouteString{
  
  static const String INITIAL_ROUTE = "/";
  static String SPLASH_SCREEN = "/splashScreen";
  static String Login = "/Login"; 
  static String Home = "/Home";
  static String Dashboard = "/Dashboard";
  static String IncomeMenus = "/IncomeMenus";
  static String AipIncome = "/AipIncome";
  static String LipIncome = "/LipIncome";
  static String RewardPoolIncome = "/RewardIncentivePoolList";
  static String RankChart = "/RankChart";
  static String KycVerification = "/KycVerification";
  static String OurServicesMenu = "/OurServicesMenu";
  static String PuchasePlan = "/PuchasePlan";
  static String PurchaseReport = "/PurchaseReport";
  static String TeamMenu = "/TeamMenu";
  static String DirectTeam = "/DirectTeam";
  static String DownlineTeam = "/DownlineTeam";
  static String IncomeLedger = "/IncomeLedger";
  static String FundMenu = "/FundMenu";
  static String ReportedMe = "/ReportedMe";
  static String DepositRequest = "/DepositRequest";
  static String FundRequestReport = "/FundRequestReport";
  static String WithdrawalReport = "/WithdrawalReport";
  static String PasswordMenu = "/PasswordMenu";
  static String ChangeLoginPassword = "/ChangeLoginPassword";
  static String ChangeTransactionPassword = "/ChangeTransactionPassword";
  static String EditProfile = "/EditProfile";
  static String RaiseTicketScreen = "/RaiseTicketScreen";
  static String RaiseTicketDetailScreen = "/RaiseTicketDetailScreen";
}