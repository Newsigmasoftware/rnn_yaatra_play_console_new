class LIPIncomeModel {
  bool? success;
  List<Data>? data;
  int? count;

  LIPIncomeModel({this.success, this.data, this.count});

  LIPIncomeModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(new Data.fromJson(v));
      });
    }
    count = json['count'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['count'] = this.count;
    return data;
  }
}

class Data {
  String? id;
  String? userId;
  String? userName;
  String? turnOver;
  String? percentage;
  String? totalIncome;
  String? totalUserSIPAmount;
  String? sIPRate;
  String? teamSIP;
  String? income;
  String? entrydate;

  Data(
      {this.id,
        this.userId,
        this.userName,
        this.turnOver,
        this.percentage,
        this.totalIncome,
        this.totalUserSIPAmount,
        this.sIPRate,
        this.teamSIP,
        this.income,
        this.entrydate});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['Id'];
    userId = json['UserId'];
    userName = json['UserName'];
    turnOver = json['TurnOver'];
    percentage = json['Percentage'];
    totalIncome = json['TotalIncome'];
    totalUserSIPAmount = json['TotalUserSIPAmount'];
    sIPRate = json['SIPRate'];
    teamSIP = json['TeamSIP'];
    income = json['Income'];
    entrydate = json['Entrydate'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Id'] = this.id;
    data['UserId'] = this.userId;
    data['UserName'] = this.userName;
    data['TurnOver'] = this.turnOver;
    data['Percentage'] = this.percentage;
    data['TotalIncome'] = this.totalIncome;
    data['TotalUserSIPAmount'] = this.totalUserSIPAmount;
    data['SIPRate'] = this.sIPRate;
    data['TeamSIP'] = this.teamSIP;
    data['Income'] = this.income;
    data['Entrydate'] = this.entrydate;
    return data;
  }
}
